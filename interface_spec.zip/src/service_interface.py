from abc import ABC, abstractmethod
from typing import Any, Dict

class ServiceInterface(ABC):
    """Generic interface for REST service operations."""

    @abstractmethod
    def call_endpoint(
        self, endpoint: str, data: Dict[str, Any] | None = None,
        method: str = "POST"
    ) -> Dict[str, Any]:
        """Call an arbitrary REST endpoint on the service."""

__all__ = ["ServiceInterface"]
